import java.util.*;
import java.io.*;

public class CompanyManagement<E>{
    private ArrayList<Employee> empList;

    //path: path of ListOfEmployees, path1: path of PLInfo.txt
    public CompanyManagement(String path, String path1) throws FileNotFoundException{
      empList = getEmployeeFromFile(path, path1);
    } 
    
	//Phan code cua sinh vien
	
    //path: path of ListOfEmployees, path1: path of PLInfo.txt
    public ArrayList<Employee> getEmployeeFromFile(String path, String path1) throws FileNotFoundException{
      ArrayList<Employee> empList = new ArrayList();
		try
		{
			FileReader fr = new FileReader(path);
			BufferedReader br = new BufferedReader(fr);
			String line = br.readLine();
				
			FileReader fr2 = new FileReader(path1);
			BufferedReader br2 = new BufferedReader(fr2);
			String line2 = br2.readLine();
			
			ArrayList<String> arr;
			Employee obj;
			boolean search = false;
				
			while(line != null && line2 != null)
			{
				String[] string1 = line.split(",");
				String[] string2 = line2.split(",");
				
				if(string1[1].equals(string2[0]) && "L".equals(string1[5]))
				{
					search = true;
					arr = new ArrayList<String>();
					for(int i=1; i<string2.length; i++)
					{
						arr.add(string2[i]);
					}
					obj = new TeamLeader(string1[1], string1[2], Integer.parseInt(string1[7]), string1[3], arr, Integer.parseInt(string1[4]),Double.parseDouble(string1[6]));
					empList.add(obj);
				}
				else if(string1[1].equals(string2[0]))
				{
					search = true;
					arr = new ArrayList<String>();
					for(int i=1; i<string2.length; i++)
					{
						arr.add(string2[i]);
					}
					obj = new Developer(string1[1], string1[2], Integer.parseInt(string1[5]), string1[3], arr, Integer.parseInt(string1[4]));
					empList.add(obj);
				}
				else
				{
					obj = new Tester(string1[1], string1[2], Integer.parseInt(string1[5]), Double.parseDouble(string1[3]), string1[4]);
					empList.add(obj);
				}
	
				if(search == false)
				{
					line = br.readLine();
				}
				else
				{
					line = br.readLine();
					line2 = br2.readLine();
					search = false;
				}
			}
			br.close();
			fr.close();
		}catch (Exception e)	
		{
			System.out.print(e);
		}
		return empList;
    }

    public ArrayList<Developer> getDeveloperByProgrammingLanguage(String pl){
      ArrayList<Developer> list = new ArrayList<Developer>();
	   Developer a;
	   ArrayList<Developer> list2 = new ArrayList<Developer>();
	   ArrayList<String> list3;
	   
	   
	   for(int i=0;i<empList.size();i++)
	   {	
		
		   if(empList.get(i) instanceof Developer)
		   {
			   a =(Developer)empList.get(i);
			   list.add(a);
		   }
	   }
	   for(int j=0;j<list.size();j++)
	   {
		   list3=list.get(j).getProgrammingLanguages();
		   for(int n=0;n<list3.size();n++)
		   {
			   if(list3.get(n).equals(pl))
			   {
				   list2.add(list.get(j));
			   }
		   }
	   }
	   return list2;
    }

    public ArrayList<Tester> getTestersHaveSalaryGreaterThan(double value){
     ArrayList<Tester> tester = new ArrayList<Tester>();
	  ArrayList<Tester> tester2 = new ArrayList<Tester>();
	  double salaryx;
	  Tester b;
	  for(int i=0;i<empList.size();i++)
	  {
		  if(empList.get(i) instanceof Tester)
		  {
			   b =(Tester)empList.get(i);
			   tester.add(b);
		  }
	  }
	  for(int j=0;j<tester.size();j++)
	  {
		  salaryx=(tester.get(j).getSalary());
		  if(salaryx>value)
		  {
			  tester2.add(tester.get(j));
		  }
	  }
	  return tester2;
    }

    public Employee getEmployeeWithHigestSalary(){
      		Developer dev;
			Tester tes;
			TeamLeader teamld;
	   
	    	double tmpEmpSalary;
	    	Employee maxSalEmp =null;
			double max=0;
	   for(int i=0;i<empList.size();i++)
	   {	
		// Check role of each employee in empList then getSalary()
		   if(empList.get(i) instanceof Developer)
		   {
			   dev =(Developer)empList.get(i);
			   tmpEmpSalary=dev.getSalary();
		   }
		   else if(empList.get(i) instanceof Tester)
		   {
				tes=(Tester)empList.get(i);
				tmpEmpSalary=tes.getSalary();
		   }
		   else
		   {
			   teamld=(TeamLeader)empList.get(i);
			   tmpEmpSalary=teamld.getSalary();
		   }
		   // Compare employee's salary with the current max. Assign if higher
			if(tmpEmpSalary>=max)
			{
				max=tmpEmpSalary;
				maxSalEmp = empList.get(i);
			}	
	   }
	    
	   return maxSalEmp;
    }

    public TeamLeader getLeaderWithMostEmployees(){
	ArrayList l1 = new ArrayList();
	ArrayList<String> list_1;
	l1.add("C++");
     TeamLeader i = new TeamLeader("52000732","nguyen van k",12,"fly",l1,2,20.5);
	 return i;
	 
    
    }

    public ArrayList<Employee> sorted(){
		ArrayList<Employee> empl = empList;
		Employee e1;
		Employee e2 ;
		for(int i=0;i<empl.size()-1;i++)
	    {
			for(int j=0;j<empl.size()-i-1;j++)
			 {
					double salary1 = getOneEmpSalary(empl.get(j));
					double salary2 = getOneEmpSalary(empl.get(j+1));
					e1 = empl.get(j);
					e2 = empl.get(j+1);
				 if(salary2>salary1)
				 {
					  
					 empl.set(j,e2);
					 empl.set(j+1,e1);
					 
				 }
				 else if(salary1==salary2)
				 {
	
					 String name1 = e1.getEmpName();
					 String name2 = e2.getEmpName();
					 String[] listname1=name1.split(" ");
					 String[] listname2=name2.split(" ");
					 String w1 =listname1[listname1.length-1];
					 String w2 =listname2[listname2.length-1];
					 
					 if(w1.charAt(0)>w2.charAt(0))
					 {
						 e1 = empl.get(j);
						 e2 = empl.get(j+1);
						 empl.set(j,e2);
						 empl.set(j+1,e1);
					 }
				 }
			 }
		
	    }
		return empl;
    }
	
	 public double getOneEmpSalary(Employee emp)
	   {
		   Developer dev;
		   Tester tes;
		   TeamLeader teamld;
		   double tmpEmpSalary;
		  
		   if(emp instanceof Developer)
		    {
			    dev =(Developer)emp;
			    tmpEmpSalary=dev.getSalary();
		    }
		    else if(emp instanceof Tester)
		    {
				 tes=(Tester)emp;
				 tmpEmpSalary=tes.getSalary();
		    }
		    else
		    {
			    teamld=(TeamLeader)emp;
			    tmpEmpSalary=teamld.getSalary();
		    }
		    return tmpEmpSalary;
	   }

	//-------------------------------------------------------------------
	
	//Print empList
	public void printEmpList(){
      for(Employee tmp : empList){
        System.out.println(tmp);
      }
    }
	
    //Methods for writing file
    public <E> boolean writeFile(String path, ArrayList<E> list){
      try {
        FileWriter writer = new FileWriter(path);
        for(E tmp : list){
          writer.write(tmp.toString());
          writer.write("\r\n");
        }
        writer.close();
        System.out.println("Successfully wrote to the file.");
      } catch (IOException e) {
        System.out.println("Error.");
        return false;
      }
      return true;
    }

    public <E> boolean writeFile(String path, E object){
      try {
        FileWriter writer = new FileWriter(path);
        writer.write(object.toString());
        writer.close();
        System.out.println("Successfully wrote to the file.");
      } catch (IOException e) {
        System.out.println("Error.");
        return false;
      }
      return true;
    }
}